// AI helper: predefined smart responses and placeholder for real API integration

const chatLog = document.getElementById('chatLog');
const aiForm = document.getElementById('aiForm');
const aiInput = document.getElementById('aiInput');

const cannedResponses = [
  {pattern: /cv|resume/i, response: "For your CV: keep it concise (1-2 pages), highlight measurable achievements, and tailor it to the role you apply for."},
  {pattern: /interview/i, response: "Interview tip: research the company, practice common questions, and prepare 3 examples that show your skills and impact."},
  {pattern: /remote/i, response: "Remote roles often value communication and time-management. Show examples of remote work or self-driven projects."},
  {pattern: /salary|pay/i, response: "Salary depends on role and experience. Research market rates and be ready to negotiate based on your value."}
];

function appendMessage(sender, text){
  const el = document.createElement('div');
  el.className = 'chat-entry ' + sender;
  el.textContent = text;
  chatLog.appendChild(el);
  chatLog.scrollTop = chatLog.scrollHeight;
}

async function fetchAIResponse(prompt){
  // Placeholder: If you connect to an AI API, implement the fetch here and return the string reply.
  // Example (server-side recommended):
  // const res = await fetch('/.netlify/functions/ai', {method:'POST', body: JSON.stringify({prompt})});
  // const result = await res.json(); return result.reply;

  // For now, attempt to match canned responses
  for(const c of cannedResponses){
    if(c.pattern.test(prompt)) return c.response;
  }
  return "I can help with CV tips, interview prep, remote-work advice, and role matching. Try asking: 'How do I improve my CV?'";
}

if(aiForm){
  aiForm.addEventListener('submit', async function(e){
    e.preventDefault();
    const q = aiInput.value.trim();
    if(!q) return;
    appendMessage('user', q);
    appendMessage('assistant', '…thinking');
    aiInput.value = '';
    const reply = await fetchAIResponse(q);
    // replace the '...thinking' element
    const thinking = chatLog.querySelector('.assistant:last-child');
    if(thinking) thinking.textContent = reply;
  });
}
