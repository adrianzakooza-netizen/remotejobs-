// Loads jobs from assets/jobs.json and renders them on jobs.html
async function loadJobs(){
  try{
    const res = await fetch('assets/jobs.json');
    const data = await res.json();
    renderJobs(data.jobs);
  }catch(e){
    console.error('Failed to load jobs', e);
    document.getElementById('jobsGrid').innerHTML = '<p>Unable to load jobs at the moment.</p>';
  }
}

function renderJobs(jobs){
  const grid = document.getElementById('jobsGrid');
  const search = document.getElementById('search');
  const filter = document.getElementById('filter');

  function draw(list){
    grid.innerHTML = '';
    if(list.length===0) grid.innerHTML = '<p>No jobs found.</p>';
    list.forEach(j=>{
      const card = document.createElement('div');
      card.className = 'job-card';
      card.innerHTML = `<h4>${j.title}</h4><p>${j.description}</p><p><strong>Type:</strong> ${j.type} • <strong>Location:</strong> ${j.location}</p><p><a href="index.html#apply" class="btn">Apply</a></p>`;
      grid.appendChild(card);
    });
  }

  // initial draw
  draw(jobs);

  // search & filter
  function update(){
    const q = search.value.toLowerCase().trim();
    const f = filter.value;
    let list = jobs.filter(j => (f==='All' || j.type===f));
    if(q) list = list.filter(j => (j.title + ' ' + j.description).toLowerCase().includes(q));
    draw(list);
  }

  search.addEventListener('input', update);
  filter.addEventListener('change', update);
}

document.addEventListener('DOMContentLoaded', loadJobs);
