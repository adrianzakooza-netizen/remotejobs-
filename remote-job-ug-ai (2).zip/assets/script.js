// Main script for Remote Job UG (AI Edition)

// Slider
const slides = document.querySelectorAll('.slide');
let idx=0;
function show(i){ slides.forEach((s,si)=> s.classList.toggle('active', si===i)); }
function next(){ idx = (idx+1)%slides.length; show(idx); }
setInterval(next,5000);

// Smooth nav
document.querySelectorAll('.main-nav a').forEach(a=>{
  a.addEventListener('click', function(e){
    // internal links handled normally, external anchors smooth scroll
    const href = this.getAttribute('href');
    if(href && href.startsWith('#')) {
      e.preventDefault();
      const t = document.querySelector(href);
      if(t) t.scrollIntoView({behavior:'smooth'});
    }
  });
});

// Form submission using EmailJS (with resume attached)
const form = document.getElementById('jobForm');
if(form){
  form.addEventListener('submit', function(e){
    e.preventDefault();
    const statusEl = document.getElementById('formStatus');
    statusEl.style.color = '#0b5f38';
    statusEl.textContent = 'Sending...';

    // sendForm automatically includes file inputs
    emailjs.sendForm('In3i1cw', '7215iYl', '#jobForm')
      .then(function(){
        // show success modal instead of alert
        statusEl.textContent = '';
        showSuccessModal('Application Sent', '✅ Your application has been sent successfully. We will contact you soon.');
        form.reset();
      }, function(err){
        console.error('EmailJS error', err);
        statusEl.style.color = '#b91c1c';
        statusEl.textContent = 'Failed to send. Please try later.';
        showSuccessModal('Error', '❌ Failed to send your application. Please try again later.');
      });
  });
}

// Success modal (animated)
function showSuccessModal(title, message){
  // create modal elements
  const modal = document.createElement('div');
  modal.className = 'modal';
  modal.innerHTML = `
    <div class="modal-panel">
      <h3>${title}</h3>
      <p>${message}</p>
    </div>
  `;
  document.body.appendChild(modal);
  // animate & auto remove
  setTimeout(()=> modal.classList.add('visible'), 50);
  setTimeout(()=> {
    modal.classList.remove('visible');
    setTimeout(()=> modal.remove(), 400);
  }, 5200);
}

// Minimal modal styles injection
const modalStyle = document.createElement('style');
modalStyle.innerHTML = `
.modal{position:fixed;left:0;right:0;top:0;bottom:0;display:flex;align-items:center;justify-content:center;pointer-events:none;opacity:0;transition:opacity 0.3s}
.modal.visible{pointer-events:auto;opacity:1}
.modal-panel{background:#fff;padding:22px 26px;border-radius:10px;box-shadow:0 10px 30px rgba(0,0,0,0.2);text-align:center;transform:translateY(20px);transition:transform 0.3s}
.modal.visible .modal-panel{transform:translateY(0)}
`;
document.head.appendChild(modalStyle);
