/* script.js - Remote Job UG site */

// Slider
const slides = document.querySelectorAll('.slide');
let current = 0;
function showSlide(idx){
  slides.forEach((s,i)=> s.classList.toggle('active', i === idx));
}
function nextSlide(){
  current = (current + 1) % slides.length;
  showSlide(current);
}
setInterval(nextSlide, 5000);

// Smooth scroll for nav links
document.querySelectorAll('nav a').forEach(a=>{
  a.addEventListener('click', function(e){
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if(target) target.scrollIntoView({behavior: 'smooth'});
  });
});

// Form submission with EmailJS (includes resume file)
document.getElementById('jobForm').addEventListener('submit', function(e){
  e.preventDefault();
  const statusEl = document.getElementById('formStatus');

  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const phone = document.getElementById('phone').value.trim();
  const jobType = document.getElementById('jobType').value;
  const message = document.getElementById('message').value.trim();
  const formEl = document.getElementById('jobForm');

  if(!name || !email || !phone || !jobType){
    alert('Please complete all required fields.');
    return;
  }

  statusEl.textContent = 'Sending...';
  // Use emailjs.sendForm to include file inputs automatically
  emailjs.sendForm('In3i1cw', '7215iYl', '#jobForm')
    .then(function(response){
      statusEl.style.color = '#0b5f38';
      statusEl.textContent = '✅ Application sent successfully. Thank you!';
      formEl.reset();
    }, function(error){
      console.error('EmailJS error:', error);
      statusEl.style.color = '#b91c1c';
      statusEl.textContent = '❌ Failed to send. Please try again later.';
      alert('Oops — something went wrong sending your application. Check console for details.');
    });
});
