// Fixed jobs-loader.js for dashboard filtering and search
async function loadJobs() {
  try {
    const res = await fetch('assets/jobs.json');
    const data = await res.json();
    renderJobs(data.jobs);
  } catch (e) {
    console.error('Failed to load jobs', e);
    document.getElementById('jobsGrid').innerHTML = '<p>Unable to load jobs at the moment.</p>';
  }
}

function renderJobs(jobs) {
  const grid = document.getElementById('jobsGrid');
  const search = document.getElementById('search');
  const filter = document.getElementById('filter');

  function draw(list) {
    grid.innerHTML = '';
    if (list.length === 0) {
      grid.innerHTML = '<p>No jobs found.</p>';
      return;
    }
    list.forEach(j => {
      const card = document.createElement('div');
      card.className = 'job-card';
      card.innerHTML = `
        <h4>${j.title}</h4>
        <p>${j.description}</p>
        <p><strong>Type:</strong> ${j.type} • <strong>Location:</strong> ${j.location}</p>
        <p><a href="index.html#apply" class="btn apply-link">Apply</a></p>
      `;
      grid.appendChild(card);
    });
  }

  function update() {
    const q = search.value.toLowerCase().trim();
    const f = filter.value;
    let list = jobs.filter(j => (f === 'All' || j.type === f));
    if (q) list = list.filter(j => (j.title + ' ' + j.description).toLowerCase().includes(q));
    draw(list);
  }

  search.addEventListener('input', update);
  filter.addEventListener('change', update);

  draw(jobs);
}

document.addEventListener('DOMContentLoaded', loadJobs);

// Smooth scroll for apply links
document.querySelectorAll('.apply-link').forEach(link => {
  link.addEventListener('click', function(e) {
    e.preventDefault();
    const applySection = document.getElementById('apply');
    if(applySection) applySection.scrollIntoView({behavior:'smooth'});
    document.getElementById('name').focus();
  });
});
